# PES6 AI Difficulty Research - fix5 experimental tweaks

DLL experimental separada del mod principal. Esta versión ya no es solo logger: aplica cambios exagerados para `diff=5` con el objetivo de probar si se nota diferencia de dificultad.

Log:

```text
D:/pes/IA/logs.txt
```

Header esperado:

```text
version=fix5_experimental_tweaks
```

## Cambios aplicados solo cuando PES6.exe+37E094C == 5

### 1. TABLE_68273

Original local stack table:

```text
40,40,24,12,10,8
```

Cambio aplicado para diff 5:

```text
8 -> 6
```

Implementación: hook en `PES6.exe+68273`, reemplazando el valor elegido para diff 5 antes de que el código haga `add eax, edi`.

### 2. TABLE_11DF53

Original local stack table:

```text
16,12,10,10,8,8
```

Cambio aplicado para diff 5:

```text
8 -> 6
```

Implementación: hook en `PES6.exe+11DF53`, reemplazando el valor elegido para diff 5 antes del `push eax`.

### 3. DIFF_ACTOR98_SCALE

Original:

```cpp
actor->field_98 = base + difficulty * 100;
```

Para diff 5 era:

```text
base + 500
```

Cambio aplicado:

```text
base + 600
```

Implementación: hook en `PES6.exe+125357`.

### 4. THRESHOLD_11E297

Original:

```cpp
threshold = 0x400 - difficulty * 48;
```

Para diff 5 era:

```text
784 / 0x310
```

Cambio aplicado:

```text
704 / 0x2C0
```

Implementación: hook en `PES6.exe+11E297`, retornando al `cmp ebp, ecx` con `ecx=0x2C0`.

### 5. GLOBAL_TABLE_78BFA8

Original global table16:

```text
10,10,6,4,3,3
```

Cambio aplicado en memoria:

```text
PES6.exe+78BFB2: 3 -> 2
```

Esto modifica solo la entrada de diff 5.

## Compilación

Visual Studio, Win32 / Release, PlatformToolset v142.

## Uso

Copiar la DLL generada al sistema de carga por Kitserver igual que las versiones anteriores.

No usar junto con otra DLL previa del proyecto de dificultad, porque ambas podrían hookear las mismas direcciones.
