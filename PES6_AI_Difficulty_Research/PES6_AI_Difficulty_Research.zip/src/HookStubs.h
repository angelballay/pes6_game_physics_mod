#pragma once

#include <cstdint>

extern uintptr_t g_DifficultyRuntimeAbs;
extern uintptr_t g_Table78BFA8Abs;

extern uintptr_t g_Return_Table68273;
extern uintptr_t g_Return_Table11DF53;
extern uintptr_t g_Return_DiffActor98;
extern uintptr_t g_Return_Threshold11E297;

extern "C" void Hook_Table68273_Tweak();
extern "C" void Hook_Table11DF53_Tweak();
extern "C" void Hook_DiffActor98_Tweak();
extern "C" void Hook_Threshold11E297_Tweak();
