#include "AiDifficultyLogger.h"
#include "MemoryReader.h"
#include "PesAddresses.h"
#include "HookStubs.h"

#include <cstdio>

namespace
{
    uint32_t ActorAddr(const PushadRegisters* r)
    {
        return r ? r->esi : 0;
    }

    uint32_t StackAddr(const PushadRegisters* r)
    {
        // Hook stubs do pushfd before pushad. PUSHAD stores ESP after PUSHFD,
        // so the saved value is originalESP - 4. Add 4 to recover the game stack.
        return r ? (r->esp + 4) : 0;
    }

    uint32_t TimerBucket(uint32_t timer)
    {
        return timer / 128;
    }

    uint32_t BxBucket(uint32_t bx)
    {
        return bx / 8;
    }
}

AiDifficultyLogger& AiDifficultyLogger::Instance()
{
    static AiDifficultyLogger instance;
    return instance;
}

AiDifficultyLogger::AiDifficultyLogger()
    : initialized_(false)
{
    InitializeCriticalSection(&cs_);
}

bool AiDifficultyLogger::Initialize()
{
    if (initialized_)
        return true;

    if (!sink_.Open("D:\\pes\\IA\\logs.txt"))
        return false;

    initialized_ = true;
    LogHeader();
    return true;
}

void AiDifficultyLogger::Shutdown()
{
    if (!initialized_)
        return;

    sink_.WriteLine("[AI_DIFFICULTY_RESEARCH] shutdown");
    sink_.Close();
    initialized_ = false;
}

void AiDifficultyLogger::LogHeader()
{
    char line[1200]{};
    _snprintf_s(line, sizeof(line), _TRUNCATE,
        "[AI_DIFFICULTY_RESEARCH] start base=%08X log=D:/pes/IA/logs.txt version=fix5_experimental_tweaks "
        "active_only_diff5=1 tweaks="
        "TABLE_68273:8->6,TABLE_11DF53:8->6,ACTOR98:+500->+600,THRESHOLD_11E297:784->704,GLOBAL_78BFA8:3->2",
        static_cast<unsigned>(PesAddresses::Base())
    );
    sink_.WriteLine(line);
}

bool AiDifficultyLogger::ShouldLogProbe(uint32_t actor, BranchId branch, uint8_t difficulty, uint8_t state16,
                                        uint16_t sub18, uint8_t actor4A, uint8_t actor48, uint32_t timer114, uint32_t bx)
{
    const int slot = static_cast<int>(((actor >> 4) + static_cast<uint32_t>(branch) * 13U) % kProbeCacheSize);
    ProbeSampleCache& item = probeCache_[slot];

    const bool changed = item.actor != actor || item.branch != branch || item.difficulty != difficulty ||
                         item.state16 != state16 || item.sub18 != sub18 || item.actor4A != actor4A ||
                         item.actor48 != actor48 || item.timerBucket != TimerBucket(timer114) ||
                         item.bxBucket != BxBucket(bx);

    item.actor = actor;
    item.branch = branch;
    item.difficulty = difficulty;
    item.state16 = state16;
    item.sub18 = sub18;
    item.actor4A = actor4A;
    item.actor48 = actor48;
    item.timerBucket = TimerBucket(timer114);
    item.bxBucket = BxBucket(bx);
    return changed;
}

void AiDifficultyLogger::LogFromHook(BranchId branch, const PushadRegisters* regs)
{
    if (!initialized_ || regs == nullptr)
        return;

    const uint32_t actor = ActorAddr(regs);
    const uint32_t esp = StackAddr(regs);
    const ULONGLONG tick = GetTickCount64();

    const uint8_t difficulty = MemoryReader::ReadU8(PesAddresses::Abs(PesAddresses::RVA_DIFFICULTY_RUNTIME));

    const uint8_t  actorState16 = MemoryReader::ReadU8(actor + 0x16);
    const uint16_t actorSub18 = MemoryReader::ReadU16(actor + 0x18);
    const uint8_t  actorTeam12 = MemoryReader::ReadU8(actor + 0x12);
    const uint8_t  actorIndex11 = MemoryReader::ReadU8(actor + 0x11);
    const uint8_t  actorFlag24 = MemoryReader::ReadU8(actor + 0x24);
    const uint8_t  actor48 = MemoryReader::ReadU8(actor + 0x48);
    const uint8_t  actor4A = MemoryReader::ReadU8(actor + 0x4A);
    const uint32_t actorTimer114 = MemoryReader::ReadU32(actor + 0x114);

    const uint32_t stack0C = MemoryReader::ReadU32(esp + 0x0C);
    const uint32_t stack10 = MemoryReader::ReadU32(esp + 0x10);
    const uint32_t stack14 = MemoryReader::ReadU32(esp + 0x14);
    const uint32_t stack20 = MemoryReader::ReadU32(esp + 0x20);

    const uint32_t bx = regs->ebx & 0xFFFF;

    bool shouldLog = true;
    EnterCriticalSection(&cs_);
    shouldLog = ShouldLogProbe(actor, branch, difficulty, actorState16, actorSub18, actor4A, actor48, actorTimer114, bx);
    LeaveCriticalSection(&cs_);

    if (!shouldLog)
        return;

    const uint16_t globalDiff5Value = MemoryReader::ReadU16(g_Table78BFA8Abs + 5 * 2, 0xFFFF);

    if (branch == BranchId::TWEAK_TABLE_68273)
    {
        const uint32_t idx = regs->edx & 0xFF;
        const uint32_t chosen = regs->eax & 0xFFFF;
        char line[1400]{};
        _snprintf_s(line, sizeof(line), _TRUNCATE,
            "[%s] tick=%I64u diff=%u/0x%02X idx=%u chosen=%u/0x%04X expected_diff5=6 "
            "actor=%08X state16=%u/0x%02X sub18=%u/0x%04X team12=%u index11=%u flag24=%u timer114=%u "
            "eax=%08X edx=%08X edi=%08X stack10=%u stack14=%u stack20=%u global78BFA8_diff5=%u",
            BranchName(branch), tick, difficulty, difficulty, idx, chosen, chosen,
            actor, actorState16, actorState16, actorSub18, actorSub18, actorTeam12, actorIndex11, actorFlag24, actorTimer114,
            regs->eax, regs->edx, regs->edi, stack10, stack14, stack20, globalDiff5Value);
        sink_.WriteLine(line);
        return;
    }

    if (branch == BranchId::TWEAK_TABLE_11DF53)
    {
        const uint32_t idx = regs->ecx & 0xFF;
        const uint32_t chosen = regs->eax & 0xFFFF;
        char line[1400]{};
        _snprintf_s(line, sizeof(line), _TRUNCATE,
            "[%s] tick=%I64u diff=%u/0x%02X idx=%u chosen=%u/0x%04X expected_diff5=6 "
            "actor=%08X state16=%u/0x%02X sub18=%u/0x%04X team12=%u index11=%u flag24=%u timer114=%u "
            "eax=%08X ecx=%08X stack0C=%u stack10=%u stack14=%u global78BFA8_diff5=%u",
            BranchName(branch), tick, difficulty, difficulty, idx, chosen, chosen,
            actor, actorState16, actorState16, actorSub18, actorSub18, actorTeam12, actorIndex11, actorFlag24, actorTimer114,
            regs->eax, regs->ecx, stack0C, stack10, stack14, globalDiff5Value);
        sink_.WriteLine(line);
        return;
    }

    if (branch == BranchId::TWEAK_ACTOR98_SCALE)
    {
        const uint32_t finalValue = regs->eax;
        const uint32_t written = MemoryReader::ReadU32(actor + 0x98);
        char line[1400]{};
        _snprintf_s(line, sizeof(line), _TRUNCATE,
            "[%s] tick=%I64u diff=%u/0x%02X final_actor98=%u written_actor98=%u original_edx_scale=%u expected_diff5_scale=600 "
            "actor=%08X state16=%u/0x%02X sub18=%u/0x%04X team12=%u index11=%u flag24=%u timer114=%u "
            "eax=%08X edx=%08X global78BFA8_diff5=%u",
            BranchName(branch), tick, difficulty, difficulty, finalValue, written, regs->edx,
            actor, actorState16, actorState16, actorSub18, actorSub18, actorTeam12, actorIndex11, actorFlag24, actorTimer114,
            regs->eax, regs->edx, globalDiff5Value);
        sink_.WriteLine(line);
        return;
    }

    if (branch == BranchId::TWEAK_THRESHOLD_11E297)
    {
        const uint32_t scaledAmount = regs->eax;
        const uint32_t threshold = regs->ecx;
        char line[1400]{};
        _snprintf_s(line, sizeof(line), _TRUNCATE,
            "[%s] tick=%I64u diff=%u/0x%02X scaled=%u/0x%X threshold=%u/0x%X expected_diff5_threshold=704 "
            "ebp=%08X pass_if_ebp_ge_threshold=%u actor=%08X state16=%u/0x%02X sub18=%u/0x%04X timer114=%u global78BFA8_diff5=%u",
            BranchName(branch), tick, difficulty, difficulty, scaledAmount, scaledAmount, threshold, threshold,
            regs->ebp, (regs->ebp >= threshold) ? 1U : 0U, actor, actorState16, actorState16, actorSub18, actorSub18, actorTimer114, globalDiff5Value);
        sink_.WriteLine(line);
        return;
    }
}

extern "C" void __cdecl AiLog_Branch(uint32_t branchId, PushadRegisters* regs)
{
    AiDifficultyLogger::Instance().LogFromHook(static_cast<BranchId>(branchId), regs);
}
