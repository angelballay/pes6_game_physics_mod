#pragma once

#include <Windows.h>
#include <cstdint>

namespace PesAddresses
{
    // Central runtime difficulty.
    constexpr uintptr_t RVA_DIFFICULTY_RUNTIME = 0x37E094C;

    // Experimental diff=5 difficulty tweak hooks.
    constexpr uintptr_t RVA_DIFF_ACTOR98_ADD   = 0x125357; // add eax,edx; mov [esi+98],eax
    constexpr uintptr_t RVA_TABLE_68273        = 0x068273; // local table 40,40,24,12,10,8
    constexpr uintptr_t RVA_TABLE_11DF53       = 0x11DF53; // local table 16,12,10,10,8,8
    constexpr uintptr_t RVA_THRESHOLD_11E297   = 0x11E297; // threshold = 0x400 - diff*48

    // Global table used by PES6.exe+126AF4.
    constexpr uintptr_t RVA_TABLE_78BFA8       = 0x78BFA8; // table16: 10,10,6,4,3,3

    inline uintptr_t Base()
    {
        return reinterpret_cast<uintptr_t>(::GetModuleHandleA(nullptr));
    }

    inline uintptr_t Abs(uintptr_t rva)
    {
        return Base() + rva;
    }
}
