#pragma once

#include <cstdint>

enum class BranchId : uint32_t
{
    NONE = 0,

    // fix5: experimental gameplay tweaks, only active when PES6.exe+37E094C == 5.
    TWEAK_TABLE_68273 = 50,        // diff5 local table value 8 -> 6
    TWEAK_TABLE_11DF53 = 51,       // diff5 local table value 8 -> 6
    TWEAK_ACTOR98_SCALE = 52,      // diff5 actor+98 scale +500 -> +600
    TWEAK_THRESHOLD_11E297 = 53,   // diff5 threshold 784 -> 704
};

inline const char* BranchName(BranchId id)
{
    switch (id)
    {
    case BranchId::NONE: return "NONE";
    case BranchId::TWEAK_TABLE_68273: return "TWEAK_TABLE_68273";
    case BranchId::TWEAK_TABLE_11DF53: return "TWEAK_TABLE_11DF53";
    case BranchId::TWEAK_ACTOR98_SCALE: return "TWEAK_ACTOR98_SCALE";
    case BranchId::TWEAK_THRESHOLD_11E297: return "TWEAK_THRESHOLD_11E297";
    default: return "UNKNOWN";
    }
}

inline bool IsEntryBranch(BranchId) { return false; }
inline bool IsResultBranch(BranchId) { return false; }
inline bool IsProbeBranch(BranchId id)
{
    return id == BranchId::TWEAK_TABLE_68273 || id == BranchId::TWEAK_TABLE_11DF53 ||
           id == BranchId::TWEAK_ACTOR98_SCALE || id == BranchId::TWEAK_THRESHOLD_11E297;
}
