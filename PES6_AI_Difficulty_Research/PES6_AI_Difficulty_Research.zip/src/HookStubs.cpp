#include "HookStubs.h"
#include "AiDifficultyLogger.h"

uintptr_t g_DifficultyRuntimeAbs = 0;
uintptr_t g_Table78BFA8Abs = 0;

uintptr_t g_Return_Table68273 = 0;
uintptr_t g_Return_Table11DF53 = 0;
uintptr_t g_Return_DiffActor98 = 0;
uintptr_t g_Return_Threshold11E297 = 0;

extern "C" __declspec(naked) void Hook_Table68273_Tweak()
{
    __asm
    {
        // Original bytes replaced:
        // 00468273 - movzx edx,byte ptr [PES6.exe+37E094C]
        // 0046827A - movzx eax,byte ptr [esp+edx+24]
        push ecx
        mov ecx, dword ptr [g_DifficultyRuntimeAbs]
        movzx edx, byte ptr [ecx]
        pop ecx

        cmp edx, 5
        jne TABLE68273_Normal

        // Experimental diff=5: original local-table value 8 -> 6.
        mov eax, 6
        jmp TABLE68273_LogAndReturn

    TABLE68273_Normal:
        movzx eax, byte ptr [esp+edx+24h]

    TABLE68273_LogAndReturn:
        // Log only after EDX/EAX have the value that will be used.
        pushfd
        pushad
        mov eax, esp
        push eax
        push 50
        call AiLog_Branch
        add esp, 8
        popad
        popfd

        // Return at 0046827F: add eax,edi
        jmp dword ptr [g_Return_Table68273]
    }
}

extern "C" __declspec(naked) void Hook_Table11DF53_Tweak()
{
    __asm
    {
        // Original bytes replaced:
        // 0051DF53 - movzx ecx,byte ptr [PES6.exe+37E094C]
        // 0051DF5A - movzx eax,byte ptr [esp+ecx+0C]
        push edx
        mov edx, dword ptr [g_DifficultyRuntimeAbs]
        movzx ecx, byte ptr [edx]
        pop edx

        cmp ecx, 5
        jne TABLE11DF53_Normal

        // Experimental diff=5: original local-table value 8 -> 6.
        mov eax, 6
        jmp TABLE11DF53_LogAndReturn

    TABLE11DF53_Normal:
        movzx eax, byte ptr [esp+ecx+0Ch]

    TABLE11DF53_LogAndReturn:
        pushfd
        pushad
        mov eax, esp
        push eax
        push 51
        call AiLog_Branch
        add esp, 8
        popad
        popfd

        // Return at 0051DF5F: push eax
        jmp dword ptr [g_Return_Table11DF53]
    }
}

extern "C" __declspec(naked) void Hook_DiffActor98_Tweak()
{
    __asm
    {
        // Original bytes replaced:
        // 00525357 - add eax,edx
        // 00525359 - mov [esi+00000098],eax
        // At this point: EAX=base, EDX=difficulty*100, ESI=actor.
        push ecx
        mov ecx, dword ptr [g_DifficultyRuntimeAbs]
        cmp byte ptr [ecx], 5
        pop ecx
        jne ACTOR98_Normal

        // Experimental diff=5: +500 -> +600.
        add eax, 600
        jmp ACTOR98_Store

    ACTOR98_Normal:
        add eax, edx

    ACTOR98_Store:
        mov dword ptr [esi+98h], eax

        pushfd
        pushad
        mov eax, esp
        push eax
        push 52
        call AiLog_Branch
        add esp, 8
        popad
        popfd

        jmp dword ptr [g_Return_DiffActor98]
    }
}

extern "C" __declspec(naked) void Hook_Threshold11E297_Tweak()
{
    __asm
    {
        // Original bytes replaced:
        // 0051E297 - movzx eax,byte ptr [PES6.exe+37E094C]
        // 0051E29E - lea eax,[eax+eax*2]
        // 0051E2A1 - shl eax,04
        // 0051E2A4 - mov ecx,00000400
        // 0051E2A9 - sub ecx,eax
        // Return at 0051E2AB: cmp ebp,ecx
        push edx
        mov edx, dword ptr [g_DifficultyRuntimeAbs]
        movzx eax, byte ptr [edx]
        pop edx

        cmp eax, 5
        jne THRESHOLD_Normal

        // Experimental diff=5:
        // original threshold = 0x400 - 5*48 = 0x310 / 784
        // custom threshold   = 0x2C0 / 704
        // Keep EAX consistent as the scaled amount: 0x400 - 0x140 = 0x2C0.
        mov eax, 00000140h
        mov ecx, 000002C0h
        jmp THRESHOLD_LogAndReturn

    THRESHOLD_Normal:
        lea eax, [eax+eax*2]
        shl eax, 4
        mov ecx, 00000400h
        sub ecx, eax

    THRESHOLD_LogAndReturn:
        pushfd
        pushad
        mov eax, esp
        push eax
        push 53
        call AiLog_Branch
        add esp, 8
        popad
        popfd

        jmp dword ptr [g_Return_Threshold11E297]
    }
}
