#!/usr/bin/env python3
"""
Analyze PES6 AI behavior blackbox logs from fix8/fix8b/fix8c/fix8d/fix8e.

VERSION: fix8e_batch_analyzer

Single-file mode, previous behavior:
  python analyze_behavior_log.py D:/pes/IA/logs.txt out_dir

Batch mode, new behavior:
  python analyze_behavior_log.py

Batch mode scans every *.txt file located in the same folder as this .py file.
For each log it creates one output folder with the log filename stem:
  tools/test1_diff5.txt  -> tools/test1_diff5/
  tools/test2_diff2.txt  -> tools/test2_diff2/

Optional batch mode for another folder:
  python analyze_behavior_log.py --batch D:/pes/IA/tests
"""
from __future__ import annotations

import csv
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

PAIR_RE = re.compile(r"(\w+)=([^\s]+)")
EVENT_KINDS = ("AI_DECISION", "AI_STATE_CHANGE", "AI_FIELD_CHANGE", "AI_11C253_FOCUS", "AI_PROBE")


def parse_line(line: str) -> Optional[Dict[str, str]]:
    kind = None
    for k in EVENT_KINDS:
        if line.startswith(f"[{k}]"):
            kind = k
            break
    if not kind:
        return None
    d: Dict[str, str] = {"kind": kind}
    for m in PAIR_RE.finditer(line):
        d[m.group(1)] = m.group(2)
    return d


def write_counter(path: Path, counter: Counter, headers=("key", "count")) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(headers)
        for k, v in counter.most_common():
            if isinstance(k, tuple):
                w.writerow([*k, v])
            else:
                w.writerow([k, v])


def sanitize_folder_name(name: str) -> str:
    # Keep accents and normal letters, but remove filesystem-problematic characters.
    cleaned = re.sub(r"[<>:\"/\\|?*\x00-\x1F]", "_", name).strip(" .")
    return cleaned or "log_analysis"


def unique_output_dir(base_dir: Path, desired_name: str) -> Path:
    desired_name = sanitize_folder_name(desired_name)
    candidate = base_dir / desired_name
    if not candidate.exists():
        return candidate
    # Reuse existing output folder if it is already an analysis directory for this log.
    # This keeps repeated runs simple: the CSVs get overwritten.
    if candidate.is_dir():
        return candidate
    suffix = 2
    while True:
        candidate = base_dir / f"{desired_name}_{suffix}"
        if not candidate.exists() or candidate.is_dir():
            return candidate
        suffix += 1


def get_float(rec: Dict[str, str], key: str) -> Optional[float]:
    value = rec.get(key)
    if value is None or value in ("?", "nan", "none", "NONE"):
        return None
    try:
        return float(value)
    except ValueError:
        return None


def analyze_log(log_path: Path, out_dir: Path) -> Dict[str, object]:
    out_dir.mkdir(parents=True, exist_ok=True)

    kind_counts: Counter = Counter()
    branch_counts: Counter = Counter()
    branch_diff_counts: Counter = Counter()
    transition_counts: Counter = Counter()
    transition_diff_counts: Counter = Counter()
    phase_counts: Counter = Counter()
    spatial_intent_counts: Counter = Counter()
    active_source_counts: Counter = Counter()
    positive_counts: Counter = Counter()
    target_token_counts: Counter = Counter()
    state_to_counts: Counter = Counter()
    state_from_counts: Counter = Counter()
    ball84_counts: Counter = Counter()
    decision_diff_counts: Counter = Counter()

    decisions: List[Dict[str, str]] = []
    positive_decisions: List[Dict[str, str]] = []

    parsed_lines = 0
    total_lines = 0

    with log_path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            total_lines += 1
            rec = parse_line(line.strip())
            if not rec:
                continue
            parsed_lines += 1
            kind_counts[rec.get("kind", "?")] += 1
            branch = rec.get("branch", "?")
            diff = rec.get("diff", "?")
            branch_counts[branch] += 1
            branch_diff_counts[(branch, diff)] += 1
            phase_counts[rec.get("phase", "?")] += 1
            spatial_intent_counts[rec.get("spatial_intent", "?")] += 1
            active_source_counts[rec.get("active_source", "?")] += 1
            ball84_counts[rec.get("ball84", "?")] += 1
            if rec.get("positive_candidate") == "1":
                positive_counts[(branch, diff)] += 1
            if rec["kind"] in ("AI_DECISION", "AI_STATE_CHANGE"):
                frm = rec.get("from", "?")
                to = rec.get("to", "?")
                transition_counts[(frm, to, branch)] += 1
                transition_diff_counts[(frm, to, diff, branch)] += 1
                state_from_counts[frm] += 1
                state_to_counts[to] += 1
            targets = rec.get("targets")
            if targets and targets != "none":
                for token in targets.split(";"):
                    token = token.strip()
                    if token:
                        target_token_counts[token.split(":")[0]] += 1
            if rec["kind"] == "AI_DECISION":
                decisions.append(rec)
                decision_diff_counts[diff] += 1
                if rec.get("positive_candidate") == "1":
                    positive_decisions.append(rec)

    write_counter(out_dir / "kind_counts.csv", kind_counts)
    write_counter(out_dir / "branch_counts.csv", branch_counts)
    write_counter(out_dir / "branch_by_diff.csv", branch_diff_counts, ("branch", "diff", "count"))
    write_counter(out_dir / "transitions.csv", transition_counts, ("from", "to", "branch", "count"))
    write_counter(out_dir / "transitions_by_diff.csv", transition_diff_counts, ("from", "to", "diff", "branch", "count"))
    write_counter(out_dir / "phase_counts.csv", phase_counts)
    write_counter(out_dir / "spatial_intent_counts.csv", spatial_intent_counts)
    write_counter(out_dir / "active_source_counts.csv", active_source_counts)
    write_counter(out_dir / "positive_by_branch_diff.csv", positive_counts, ("branch", "diff", "count"))
    write_counter(out_dir / "target_token_counts.csv", target_token_counts)
    write_counter(out_dir / "state_to_counts.csv", state_to_counts, ("state_to", "count"))
    write_counter(out_dir / "state_from_counts.csv", state_from_counts, ("state_from", "count"))
    write_counter(out_dir / "ball84_counts.csv", ball84_counts, ("ball84", "count"))
    write_counter(out_dir / "decision_diff_counts.csv", decision_diff_counts, ("diff", "count"))

    decision_fields = [
        "tick", "diff", "branch", "actor", "team12", "index11", "from", "to",
        "state_changed", "field_changed", "positive_candidate", "phase", "spatial_intent",
        "active", "active_valid", "active_source", "ball_owner", "ball_owner_valid", "ball_owner_source",
        "ball84", "ball88", "ball_actor_id",
        "actor_best", "active_best", "dist_actor_ball", "dist_actor_active", "dist_active_ball", "dist_actor_ball_pred",
        "actor_b0", "actor_dir", "actor_r1", "actor_r2", "actor_l2", "actor_p114", "actor_anim30",
        "active_b0", "active_dir", "active_r1", "active_r2", "active_l2", "active_p114", "active_anim30",
        "ball50", "targets",
    ]
    with (out_dir / "ai_decisions_sample.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=decision_fields, extrasaction="ignore")
        w.writeheader()
        for rec in decisions[:5000]:
            w.writerow(rec)

    with (out_dir / "positive_decisions.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=decision_fields, extrasaction="ignore")
        w.writeheader()
        for rec in positive_decisions:
            w.writerow(rec)

    # Spatial summary for positive decisions, useful for the PES6 AI research.
    spatial_fields = [
        "metric", "count", "min", "avg", "max",
    ]
    spatial_metrics = ["dist_actor_ball", "dist_actor_active", "dist_active_ball", "dist_actor_ball_pred"]
    with (out_dir / "positive_spatial_summary.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(spatial_fields)
        for key in spatial_metrics:
            vals = [get_float(rec, key) for rec in positive_decisions]
            vals = [v for v in vals if v is not None]
            if vals:
                w.writerow([key, len(vals), min(vals), sum(vals) / len(vals), max(vals)])
            else:
                w.writerow([key, 0, "", "", ""])

    with (out_dir / "analysis_report.md").open("w", encoding="utf-8") as f:
        f.write("# PES6 AI behavior log analysis\n\n")
        f.write(f"Input log: `{log_path}`\n\n")
        f.write(f"Total raw lines: {total_lines}\n\n")
        f.write(f"Total parsed events: {parsed_lines}\n\n")
        f.write("## Event kinds\n")
        for k, v in kind_counts.most_common():
            f.write(f"- {k}: {v}\n")
        f.write("\n## Runtime diff values in AI_DECISION\n")
        for k, v in decision_diff_counts.most_common():
            f.write(f"- {k}: {v}\n")
        f.write("\n## Top branches\n")
        for k, v in branch_counts.most_common(20):
            f.write(f"- {k}: {v}\n")
        f.write("\n## Positive candidates by branch/diff\n")
        for (branch, diff), v in positive_counts.most_common(20):
            f.write(f"- {branch} diff={diff}: {v}\n")
        f.write("\n## Top transitions\n")
        for (frm, to, branch), v in transition_counts.most_common(30):
            f.write(f"- {frm} -> {to} via {branch}: {v}\n")
        f.write("\n## Spatial intent\n")
        for k, v in spatial_intent_counts.most_common(20):
            f.write(f"- {k}: {v}\n")

    return {
        "log": str(log_path),
        "out_dir": str(out_dir),
        "total_lines": total_lines,
        "parsed_events": parsed_lines,
        "ai_decisions": kind_counts.get("AI_DECISION", 0),
        "state_changes": kind_counts.get("AI_STATE_CHANGE", 0),
        "positive_events": sum(positive_counts.values()),
        "top_diff": decision_diff_counts.most_common(1)[0][0] if decision_diff_counts else "?",
        "top_branch": branch_counts.most_common(1)[0][0] if branch_counts else "?",
    }


def find_batch_logs(folder: Path) -> List[Path]:
    # Only immediate *.txt files in the selected folder. Do not recurse into output folders.
    logs = []
    for p in sorted(folder.glob("*.txt")):
        if p.is_file():
            logs.append(p)
    return logs


def run_batch(folder: Path) -> int:
    folder = folder.resolve()
    if not folder.exists():
        print(f"ERROR: batch folder does not exist: {folder}")
        print("Tip: if the folder is next to this .py, use: python analyze_behavior_log.py --batch test")
        print("Tip: or put .txt logs next to this .py and run: python analyze_behavior_log.py")
        return 2
    if not folder.is_dir():
        print(f"ERROR: batch path is not a folder: {folder}")
        return 2
    logs = find_batch_logs(folder)
    if not logs:
        print(f"No *.txt files found in {folder}")
        return 1

    print(f"Batch mode: found {len(logs)} txt file(s) in {folder}")
    summaries: List[Dict[str, object]] = []
    for log_path in logs:
        out_dir = unique_output_dir(folder, log_path.stem)
        print(f"- Analyzing {log_path.name} -> {out_dir.name}/")
        try:
            summaries.append(analyze_log(log_path, out_dir))
        except Exception as exc:  # keep batch running if one file is bad
            print(f"  ERROR analyzing {log_path.name}: {exc}")
            summaries.append({
                "log": str(log_path),
                "out_dir": str(out_dir),
                "error": str(exc),
            })

    summary_path = folder / "_batch_summary.csv"
    fields = ["log", "out_dir", "total_lines", "parsed_events", "ai_decisions", "state_changes", "positive_events", "top_diff", "top_branch", "error"]
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for row in summaries:
            w.writerow(row)

    print(f"Wrote batch summary to {summary_path}")
    return 0


def main() -> int:
    print("PES6 AI behavior analyzer VERSION=fix8e_batch_analyzer")
    script_dir = Path(__file__).resolve().parent

    # New default behavior: no args => scan every txt next to the .py file.
    if len(sys.argv) == 1:
        return run_batch(script_dir)

    # Optional explicit batch folder.
    if len(sys.argv) in (2, 3) and sys.argv[1] == "--batch":
        folder = Path(sys.argv[2]) if len(sys.argv) == 3 else script_dir
        # Windows-friendly: --batch test means a folder named test relative to the current terminal folder.
        if not folder.is_absolute():
            folder = Path.cwd() / folder
        return run_batch(folder)

    # Previous single-file behavior.
    if len(sys.argv) >= 3:
        log_path = Path(sys.argv[1])
        out_dir = Path(sys.argv[2])
        summary = analyze_log(log_path, out_dir)
        print(f"Wrote analysis to {out_dir}")
        print(f"Parsed events: {summary.get('parsed_events', 0)}")
        return 0

    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
