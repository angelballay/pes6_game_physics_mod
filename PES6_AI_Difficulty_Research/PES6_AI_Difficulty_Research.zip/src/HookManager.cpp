#include "HookManager.h"
#include "HookStubs.h"
#include "PesAddresses.h"

#include <cstring>

HookManager& HookManager::Instance()
{
    static HookManager instance;
    return instance;
}

bool HookManager::InstallAll()
{
    const uintptr_t base = PesAddresses::Base();
    if (base == 0)
        return false;

    g_DifficultyRuntimeAbs = base + PesAddresses::RVA_DIFFICULTY_RUNTIME;
    g_Table78BFA8Abs = base + PesAddresses::RVA_TABLE_78BFA8;

    g_Return_Table68273 = base + 0x6827F;
    g_Return_Table11DF53 = base + 0x11DF5F;
    g_Return_DiffActor98 = base + 0x12535F;
    g_Return_Threshold11E297 = base + 0x11E2AB;

    bool ok = true;

    // Data patch: GLOBAL_TABLE_78BFA8 diff5 value.
    // Original table16: [10,10,6,4,3,3]
    // diff5 entry is RVA 78BFA8 + 5*2 = 78BFB2.
    ok = ok && WriteU16(base + PesAddresses::RVA_TABLE_78BFA8 + 5 * 2, 2);

    // Local stack table 40,40,24,12,10,8.
    // Replace only the value used by diff=5: 8 -> 6.
    // Original bytes covered:
    // 00468273 0F B6 15 4C 09 BE 03       movzx edx,[diff]
    // 0046827A 0F B6 44 14 24             movzx eax,[esp+edx+24]
    ok = ok && InstallJump(base + PesAddresses::RVA_TABLE_68273, reinterpret_cast<void*>(&Hook_Table68273_Tweak), 12);

    // Local stack table 16,12,10,10,8,8.
    // Replace only the value used by diff=5: 8 -> 6.
    // Original bytes covered:
    // 0051DF53 0F B6 0D 4C 09 BE 03       movzx ecx,[diff]
    // 0051DF5A 0F B6 44 0C 0C             movzx eax,[esp+ecx+0C]
    ok = ok && InstallJump(base + PesAddresses::RVA_TABLE_11DF53, reinterpret_cast<void*>(&Hook_Table11DF53_Tweak), 12);

    // actor+98 scale.
    // Original diff5 effective add: +500. Custom: +600.
    // Original bytes covered:
    // 00525357 03 C2                         add eax,edx
    // 00525359 89 86 98 00 00 00             mov [esi+98],eax
    ok = ok && InstallJump(base + PesAddresses::RVA_DIFF_ACTOR98_ADD, reinterpret_cast<void*>(&Hook_DiffActor98_Tweak), 8);

    // Dynamic threshold.
    // Original diff5: 0x400 - 5*48 = 0x310 / 784.
    // Custom diff5:  0x2C0 / 704.
    // Original bytes covered through sub ecx,eax, returning to cmp ebp,ecx.
    ok = ok && InstallJump(base + PesAddresses::RVA_THRESHOLD_11E297, reinterpret_cast<void*>(&Hook_Threshold11E297_Tweak), 20);

    return ok;
}

void HookManager::RemoveAll()
{
    // Experimental DLL: no runtime unhook for now.
}

bool HookManager::InstallJump(uintptr_t target, void* detour, size_t length)
{
    if (length < 5 || target == 0 || detour == nullptr)
        return false;

    DWORD oldProtect = 0;
    if (!VirtualProtect(reinterpret_cast<void*>(target), length, PAGE_EXECUTE_READWRITE, &oldProtect))
        return false;

    const uintptr_t src = target;
    const uintptr_t dst = reinterpret_cast<uintptr_t>(detour);
    const int32_t rel = static_cast<int32_t>(dst - src - 5);

    auto* bytes = reinterpret_cast<uint8_t*>(target);
    bytes[0] = 0xE9;
    std::memcpy(bytes + 1, &rel, sizeof(rel));

    for (size_t i = 5; i < length; ++i)
        bytes[i] = 0x90;

    FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void*>(target), length);

    DWORD temp = 0;
    VirtualProtect(reinterpret_cast<void*>(target), length, oldProtect, &temp);
    return true;
}

bool HookManager::WriteU16(uintptr_t target, uint16_t value)
{
    if (target == 0)
        return false;

    DWORD oldProtect = 0;
    if (!VirtualProtect(reinterpret_cast<void*>(target), sizeof(value), PAGE_EXECUTE_READWRITE, &oldProtect))
        return false;

    *reinterpret_cast<uint16_t*>(target) = value;
    FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void*>(target), sizeof(value));

    DWORD temp = 0;
    VirtualProtect(reinterpret_cast<void*>(target), sizeof(value), oldProtect, &temp);
    return true;
}
